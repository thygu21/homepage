# Mini U-Campus
Course Management System

[YouTube](https://youtu.be/yUsFa4jA-eE)
